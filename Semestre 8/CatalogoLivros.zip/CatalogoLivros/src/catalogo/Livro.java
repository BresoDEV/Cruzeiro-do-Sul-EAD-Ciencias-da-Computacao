package catalogo;

/** Entidade do catálogo. Os atributos privados são expostos por métodos de leitura. */
public class Livro {
    private final long id;
    private final String titulo;
    private final String autor;
    private final int ano;
    private final String genero;
    private final String sinopse;

    public Livro(long id, String titulo, String autor, int ano, String genero, String sinopse) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.ano = ano;
        this.genero = genero;
        this.sinopse = sinopse;
    }
    public long getId() { return id; }
    public String getTitulo() { return titulo; }
    public String getAutor() { return autor; }
    public int getAno() { return ano; }
    public String getGenero() { return genero; }
    public String getSinopse() { return sinopse; }
}
