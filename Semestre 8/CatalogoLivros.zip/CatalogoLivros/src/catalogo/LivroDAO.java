package catalogo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/** Único componente que executa as operações SQL dos livros. */
public class LivroDAO {
    private final Banco banco;
    public LivroDAO(Banco banco) { this.banco = banco; }

    /** Lista todos os livros ou procura um trecho literal no título e no autor. */
    public List<Livro> listar(String busca) throws SQLException {
        String sql = "SELECT id, titulo, autor, ano, genero, sinopse FROM livros "
            + "WHERE LOWER(titulo) LIKE ? ESCAPE '!' OR LOWER(autor) LIKE ? ESCAPE '!' "
            + "ORDER BY LOWER(titulo), id";
        // Os curingas digitados pelo usuário são tratados como caracteres literais.
        String trecho = busca.toLowerCase(java.util.Locale.ROOT)
            .replace("!", "!!").replace("%", "!%").replace("_", "!_");
        List<Livro> livros = new ArrayList<>();
        try (Connection conexao = banco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, "%" + trecho + "%");
            stmt.setString(2, "%" + trecho + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) livros.add(ler(rs));
            }
        }
        return livros;
    }

    /** Retorna o livro identificado ou null quando ele não existe. */
    public Livro buscar(long id) throws SQLException {
        try (Connection conexao = banco.conectar();
             PreparedStatement stmt = conexao.prepareStatement("SELECT * FROM livros WHERE id = ?")) {
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) { return rs.next() ? ler(rs) : null; }
        }
    }

    /** Insere um livro novo ou atualiza um existente. Retorna false se o id não existir. */
    public boolean salvar(Livro livro) throws SQLException {
        String sql = livro.getId() == 0
            ? "INSERT INTO livros (titulo, autor, ano, genero, sinopse) VALUES (?, ?, ?, ?, ?)"
            : "UPDATE livros SET titulo = ?, autor = ?, ano = ?, genero = ?, sinopse = ? WHERE id = ?";
        try (Connection conexao = banco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, livro.getTitulo());
            stmt.setString(2, livro.getAutor());
            stmt.setInt(3, livro.getAno());
            stmt.setString(4, livro.getGenero());
            stmt.setString(5, livro.getSinopse());
            if (livro.getId() != 0) stmt.setLong(6, livro.getId());
            return stmt.executeUpdate() == 1;
        }
    }

    /** Exclui somente o livro cujo identificador foi recebido. */
    public boolean excluir(long id) throws SQLException {
        try (Connection conexao = banco.conectar();
             PreparedStatement stmt = conexao.prepareStatement("DELETE FROM livros WHERE id = ?")) {
            stmt.setLong(1, id);
            return stmt.executeUpdate() == 1;
        }
    }

    private Livro ler(ResultSet rs) throws SQLException {
        return new Livro(rs.getLong("id"), rs.getString("titulo"), rs.getString("autor"),
                         rs.getInt("ano"), rs.getString("genero"), rs.getString("sinopse"));
    }
}
