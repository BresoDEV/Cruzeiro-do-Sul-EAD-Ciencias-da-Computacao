package catalogo;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import org.apache.catalina.Context;
import org.apache.catalina.startup.Tomcat;
import org.apache.tomcat.util.http.Rfc6265CookieProcessor;

/** Inicializa banco, controlador e servidor local, sem instalação separada do Tomcat. */
public class App {
    public static void main(String[] args) throws Exception {
        Path raiz = Path.of(System.getProperty("catalogo.home", ".")).toAbsolutePath().normalize();
        Banco banco = new Banco(raiz);
        banco.inicializar(raiz);
        int porta = Integer.getInteger("catalogo.porta", 8080);
        if (porta < 1 || porta > 65535) throw new IllegalArgumentException("Porta inválida.");
        Files.createDirectories(raiz.resolve("temporarios/tomcat"));

        Tomcat tomcat = new Tomcat();
        tomcat.setBaseDir(raiz.resolve("temporarios/tomcat").toString());
        tomcat.setPort(porta);
        tomcat.getConnector().setProperty("address", "127.0.0.1");
        tomcat.getConnector().setMaxPostSize(32768);
        Context contexto = tomcat.addWebapp("", raiz.resolve("webapp").toString());
        contexto.setParentClassLoader(App.class.getClassLoader());
        contexto.setUseHttpOnly(true);
        Rfc6265CookieProcessor cookies = new Rfc6265CookieProcessor();
        cookies.setSameSiteCookies("Lax");
        contexto.setCookieProcessor(cookies);
        Tomcat.addServlet(contexto, "livros", new LivroServlet(new LivroDAO(banco)));
        contexto.addServletMappingDecoded("/livros", "livros");
        Tomcat.addServlet(contexto, "inicio", new HttpServlet() {
            @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
                resp.sendRedirect(req.getContextPath() + "/livros");
            }
        });
        contexto.addServletMappingDecoded("", "inicio");

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try { tomcat.stop(); tomcat.destroy(); }
            catch (Exception e) { System.err.println("Encerramento do servidor: " + e.getMessage()); }
        }));
        tomcat.start();
        System.out.println("\nCATALOGO PRONTO: http://127.0.0.1:" + porta + "/livros");
        System.out.println("Banco salvo em: " + raiz.resolve("dados/catalogo.mv.db"));
        System.out.println("Mantenha esta janela aberta. Para encerrar, pressione Ctrl+C.\n");
        tomcat.getServer().await();
    }
}
