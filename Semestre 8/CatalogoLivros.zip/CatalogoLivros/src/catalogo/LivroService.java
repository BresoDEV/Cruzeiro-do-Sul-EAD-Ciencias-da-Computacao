package catalogo;

import java.time.Year;
import java.util.LinkedHashMap;
import java.util.Map;

/** Regras de preenchimento, aplicadas no servidor antes de acessar o banco. */
public class LivroService {
    public Livro validar(long id, Map<String, String> campos) throws ValidacaoException {
        Map<String, String> erros = new LinkedHashMap<>();
        String titulo = texto(campos, "titulo", "Informe o título.", 255, erros);
        String autor = texto(campos, "autor", "Informe o autor.", 255, erros);
        String genero = texto(campos, "genero", "Informe o gênero.", 100, erros);
        String sinopse = texto(campos, "sinopse", "Informe uma breve sinopse.", 3000, erros);
        String anoTexto = campos.getOrDefault("ano", "").strip();
        int ano = 0;

        if (anoTexto.isEmpty()) {
            erros.put("ano", "Informe o ano de publicação.");
        } else {
            try {
                ano = Integer.parseInt(anoTexto);
                if (ano < 1 || ano > Year.now().getValue()) {
                    erros.put("ano", "Informe um ano entre 1 e " + Year.now().getValue() + ".");
                }
            } catch (NumberFormatException erro) {
                erros.put("ano", "Digite um número inteiro para o ano, como 1937.");
            }
        }
        if (!erros.isEmpty()) throw new ValidacaoException(erros);
        return new Livro(id, titulo, autor, ano, genero, sinopse);
    }

    private String texto(Map<String, String> campos, String chave, String obrigatorio,
                         int limite, Map<String, String> erros) {
        String valor = campos.getOrDefault(chave, "").strip();
        if (valor.isEmpty()) erros.put(chave, obrigatorio);
        else if (valor.length() > limite) erros.put(chave, "Use no máximo " + limite + " caracteres.");
        return valor;
    }
}
