package catalogo;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.time.Year;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Recebe requisições HTTP e encaminha os resultados para as páginas JSP. */
public class LivroServlet extends HttpServlet {
    private static final Logger LOG = Logger.getLogger(LivroServlet.class.getName());
    private final LivroDAO dao;
    private final LivroService service = new LivroService();

    public LivroServlet(LivroDAO dao) { this.dao = dao; }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setHeader("X-Content-Type-Options", "nosniff");
        resp.setHeader("X-Frame-Options", "DENY");
        resp.setHeader("Cache-Control", "no-store");
        resp.setHeader("Content-Security-Policy", "default-src 'self'; style-src 'self'; "
            + "script-src 'none'; img-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'");
        super.service(req, resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        preparar(req);
        String acao = parametro(req, "acao");
        try {
            switch (acao) {
                case "", "listar":
                    String busca = parametro(req, "busca").strip();
                    if (busca.length() > 255) {
                        erro(req, resp, 400, "Use no máximo 255 caracteres na busca.");
                        return;
                    }
                    req.setAttribute("busca", busca);
                    req.setAttribute("livros", dao.listar(busca));
                    pagina(req, resp, "lista");
                    break;
                case "novo":
                    req.setAttribute("campos", Map.of());
                    pagina(req, resp, "formulario");
                    break;
                case "editar", "detalhes":
                    Livro livro = dao.buscar(id(req, false));
                    if (livro == null) {
                        erro(req, resp, 404, "Esse livro não foi encontrado.");
                        return;
                    }
                    req.setAttribute("livro", livro);
                    req.setAttribute("campos", campos(livro));
                    pagina(req, resp, acao.equals("editar") ? "formulario" : "detalhes");
                    break;
                default:
                    erro(req, resp, 404, "A página solicitada não foi encontrada.");
            }
        } catch (IllegalArgumentException e) {
            erro(req, resp, 400, "O identificador do livro é inválido.");
        } catch (SQLException e) {
            falhaBanco(req, resp, e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession sessao = req.getSession(false);
        Object token = sessao == null ? null : sessao.getAttribute("csrf");
        if (token == null || !token.equals(req.getParameter("csrf"))) {
            erro(req, resp, 403, "O formulário expirou. Volte ao catálogo e tente novamente.");
            return;
        }
        preparar(req);
        String acao = parametro(req, "acao");
        Map<String, String> campos = campos(req);
        req.setAttribute("campos", campos);
        try {
            switch (acao) {
                case "salvar":
                    Livro livro = service.validar(id(req, true), campos);
                    if (!dao.salvar(livro)) {
                        erro(req, resp, 404, "Esse livro não foi encontrado para edição.");
                        return;
                    }
                    redirecionar(resp, req.getContextPath() + "/livros?ok=salvo");
                    break;
                case "excluir":
                    if (!parametro(req, "confirmacao").equals("sim")) {
                        erro(req, resp, 400, "Confirme a exclusão na tela de detalhes do livro.");
                        return;
                    }
                    if (!dao.excluir(id(req, false))) {
                        erro(req, resp, 404, "Esse livro não foi encontrado para exclusão.");
                        return;
                    }
                    redirecionar(resp, req.getContextPath() + "/livros?ok=excluido");
                    break;
                default:
                    erro(req, resp, 400, "A operação solicitada é inválida.");
            }
        } catch (ValidacaoException e) {
            resp.setStatus(422);
            req.setAttribute("erros", e.getErros());
            pagina(req, resp, "formulario");
        } catch (IllegalArgumentException e) {
            erro(req, resp, 400, "O identificador do livro é inválido.");
        } catch (SQLException e) {
            // Os dados preenchidos continuam disponíveis para uma nova tentativa.
            LOG.log(Level.SEVERE, "Falha na gravação do catálogo", e);
            resp.setStatus(503);
            if (acao.equals("salvar")) {
                req.setAttribute("falha", "Não foi possível salvar no banco de dados. "
                    + "Os campos foram mantidos. Tente novamente.");
                pagina(req, resp, "formulario");
            } else {
                erro(req, resp, 503, "Não foi possível excluir no banco de dados. Tente novamente.");
            }
        }
    }

    private void preparar(HttpServletRequest req) {
        HttpSession sessao = req.getSession();
        if (sessao.getAttribute("csrf") == null) sessao.setAttribute("csrf", UUID.randomUUID().toString());
        req.setAttribute("anoAtual", Year.now().getValue());
    }

    private String parametro(HttpServletRequest req, String chave) {
        String valor = req.getParameter(chave);
        return valor == null ? "" : valor;
    }

    private long id(HttpServletRequest req, boolean permitirNovo) {
        String valor = parametro(req, "id");
        if (permitirNovo && valor.isBlank()) return 0;
        long id = Long.parseLong(valor);
        if (id < 1) throw new IllegalArgumentException("Id inválido");
        return id;
    }

    private Map<String, String> campos(HttpServletRequest req) {
        Map<String, String> valores = new LinkedHashMap<>();
        for (String chave : new String[]{"id", "titulo", "autor", "ano", "genero", "sinopse"}) {
            valores.put(chave, parametro(req, chave));
        }
        return valores;
    }

    private Map<String, String> campos(Livro livro) {
        return Map.of("id", String.valueOf(livro.getId()), "titulo", livro.getTitulo(),
            "autor", livro.getAutor(), "ano", String.valueOf(livro.getAno()),
            "genero", livro.getGenero(), "sinopse", livro.getSinopse());
    }

    private void pagina(HttpServletRequest req, HttpServletResponse resp, String nome)
            throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/views/" + nome + ".jsp").forward(req, resp);
    }

    private void erro(HttpServletRequest req, HttpServletResponse resp, int status, String mensagem)
            throws ServletException, IOException {
        resp.setStatus(status);
        req.setAttribute("mensagem", mensagem);
        pagina(req, resp, "erro");
    }

    private void falhaBanco(HttpServletRequest req, HttpServletResponse resp, SQLException e)
            throws ServletException, IOException {
        LOG.log(Level.SEVERE, "Falha na consulta do catálogo", e);
        erro(req, resp, 503, "Não foi possível consultar o banco de dados. Tente novamente.");
    }

    private void redirecionar(HttpServletResponse resp, String destino) {
        resp.setStatus(303);
        resp.setHeader("Location", destino);
    }
}
