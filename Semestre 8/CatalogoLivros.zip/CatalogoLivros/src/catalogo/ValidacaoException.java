package catalogo;

import java.util.LinkedHashMap;
import java.util.Map;

/** Transporta as mensagens de validação sem misturá-las a erros do banco. */
public class ValidacaoException extends Exception {
    private final Map<String, String> erros;
    public ValidacaoException(Map<String, String> erros) {
        super("Há campos que precisam de correção.");
        this.erros = new LinkedHashMap<>(erros);
    }
    public Map<String, String> getErros() { return new LinkedHashMap<>(erros); }
}
