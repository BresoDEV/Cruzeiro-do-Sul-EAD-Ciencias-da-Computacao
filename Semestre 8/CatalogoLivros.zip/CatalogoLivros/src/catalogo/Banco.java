package catalogo;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/** Centraliza a conexão JDBC com o banco H2 salvo em arquivo. */
public class Banco {
    private final String url;

    public Banco(Path raiz) throws IOException {
        Path pasta = raiz.resolve("dados");
        Files.createDirectories(pasta);
        url = "jdbc:h2:file:" + pasta.resolve("catalogo").toAbsolutePath().toString().replace('\\', '/');
    }

    public Connection conectar() throws SQLException {
        // Banco local de exercício, sem console web ou servidor H2 habilitados.
        return DriverManager.getConnection(url, "sa", "");
    }

    public void inicializar(Path raiz) throws IOException, SQLException {
        String sql = Files.readString(raiz.resolve("banco/schema.sql"), StandardCharsets.UTF_8);
        // try-with-resources fecha Statement e Connection inclusive quando há erro.
        try (Connection conexao = conectar(); Statement stmt = conexao.createStatement()) {
            stmt.execute(sql);
        }
    }
}
