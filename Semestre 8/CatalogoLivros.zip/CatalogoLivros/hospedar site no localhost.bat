@echo off
 

set "CATALOGO_CP=lib\ecj-3.33.0.jar;lib\h2-2.5.252.jar;lib\jakarta.servlet.jsp.jstl-3.0.1.jar;lib\jakarta.servlet.jsp.jstl-api-3.0.2.jar;lib\tomcat-annotations-api-10.1.61.jar;lib\tomcat-embed-core-10.1.61.jar;lib\tomcat-embed-el-10.1.61.jar;lib\tomcat-embed-jasper-10.1.61.jar"

javac -encoding UTF-8 --release 17 -cp "%CATALOGO_CP%" -d "build" src\catalogo\*.java


echo link: http://127.0.0.1:8080/livros
echo.

java -Dfile.encoding=UTF-8 -cp "build;%CATALOGO_CP%" catalogo.App

cls
goto fim

:pausa
pause

:fim
popd
endlocal
