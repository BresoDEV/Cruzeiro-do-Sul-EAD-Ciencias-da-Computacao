<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ include file="cabecalho.jspf" %>
<section class="vazio"><p class="sobretitulo">NÃO FOI POSSÍVEL CONCLUIR</p><h1>Vamos tentar novamente?</h1>
<p role="alert"><c:out value="${mensagem}"/></p>
<a class="botao" href="${pageContext.request.contextPath}/livros">Voltar ao catálogo</a></section>
<%@ include file="rodape.jspf" %>
