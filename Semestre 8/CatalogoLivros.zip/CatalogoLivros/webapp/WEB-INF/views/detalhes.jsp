<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ include file="cabecalho.jspf" %>
<a class="voltar" href="${pageContext.request.contextPath}/livros">← Voltar ao catálogo</a>
<section class="abertura"><div><p class="sobretitulo">DETALHES DO LIVRO</p><h1><c:out value="${livro.titulo}"/></h1>
<p class="apoio"><c:out value="${livro.autor}"/></p></div>
<a class="botao" href="${pageContext.request.contextPath}/livros?acao=editar&amp;id=${livro.id}">Editar livro</a></section>
<article class="painel detalhes">
<dl><div><dt>Ano de publicação</dt><dd><c:out value="${livro.ano}"/></dd></div>
<div><dt>Gênero</dt><dd><c:out value="${livro.genero}"/></dd></div></dl>
<h2>Sinopse</h2><p class="sinopse"><c:out value="${livro.sinopse}"/></p>
</article>
<section class="exclusao"><h2>Excluir este livro</h2><p>O cadastro será removido do catálogo. Essa ação não pode ser desfeita.</p>
<form method="post" action="${pageContext.request.contextPath}/livros">
<input type="hidden" name="acao" value="excluir"><input type="hidden" name="id" value="${livro.id}">
<input type="hidden" name="csrf" value="<c:out value='${sessionScope.csrf}'/>">
<label class="confirmacao"><input type="checkbox" name="confirmacao" value="sim" required> Confirmo que quero excluir este livro.</label>
<button class="botao perigo" type="submit">Excluir livro</button>
</form></section>
<%@ include file="rodape.jspf" %>
