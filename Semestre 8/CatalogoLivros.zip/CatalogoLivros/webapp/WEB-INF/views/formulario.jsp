<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ include file="cabecalho.jspf" %>
<a class="voltar" href="${pageContext.request.contextPath}/livros">← Voltar ao catálogo</a>
<section class="abertura"><div>
<h1><c:choose><c:when test="${empty campos.id}">Cadastrar livro</c:when><c:otherwise>Editar livro</c:otherwise></c:choose></h1>
</div></section>
<c:if test="${not empty erros}"><div class="aviso falha" role="alert"><strong>Revise os campos indicados.</strong> Seus dados foram mantidos para correção.</div></c:if>
<c:if test="${not empty falha}"><div class="aviso falha" role="alert"><c:out value="${falha}"/></div></c:if>
<form method="post" action="${pageContext.request.contextPath}/livros" class="painel formulario" novalidate>
    <input type="hidden" name="acao" value="salvar">
    <input type="hidden" name="id" value="<c:out value='${campos.id}'/>">
    <input type="hidden" name="csrf" value="<c:out value='${sessionScope.csrf}'/>">
    <div class="campo"><label for="titulo">Título</label>
    <input id="titulo" name="titulo" maxlength="255" value="<c:out value='${campos.titulo}'/>" aria-describedby="erro-titulo" required>
    <span class="erro" id="erro-titulo"><c:out value="${erros.titulo}"/></span></div>
    <div class="campo"><label for="autor">Autor</label>
    <input id="autor" name="autor" maxlength="255" value="<c:out value='${campos.autor}'/>" aria-describedby="erro-autor" required>
    <span class="erro" id="erro-autor"><c:out value="${erros.autor}"/></span></div>
    <div class="dupla">
    <div class="campo"><label for="ano">Ano de publicação</label>
    <input id="ano" name="ano" inputmode="numeric" maxlength="12" value="<c:out value='${campos.ano}'/>" aria-describedby="dica-ano erro-ano" required>
    <span class="dica" id="dica-ano">Entre 1 e <c:out value="${anoAtual}"/>.</span>
    <span class="erro" id="erro-ano"><c:out value="${erros.ano}"/></span></div>
    <div class="campo"><label for="genero">Gênero</label>
    <input id="genero" name="genero" maxlength="100" value="<c:out value='${campos.genero}'/>" placeholder="Ex.: Fantasia" aria-describedby="erro-genero" required>
    <span class="erro" id="erro-genero"><c:out value="${erros.genero}"/></span></div></div>
    <div class="campo"><label for="sinopse">Sinopse</label>
    <textarea id="sinopse" name="sinopse" rows="5" maxlength="3000" aria-describedby="erro-sinopse" required><c:out value="${campos.sinopse}"/></textarea>
    <span class="erro" id="erro-sinopse"><c:out value="${erros.sinopse}"/></span></div>
    <div class="linha"><button class="botao" type="submit">Salvar livro</button>
    <a class="botao secundario" href="${pageContext.request.contextPath}/livros">Cancelar</a></div>
</form>
<%@ include file="rodape.jspf" %>
