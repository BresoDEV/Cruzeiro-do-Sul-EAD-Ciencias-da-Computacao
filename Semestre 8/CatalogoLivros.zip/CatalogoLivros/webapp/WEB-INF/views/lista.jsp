<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ include file="cabecalho.jspf" %>
<section class="abertura">
    <div><h1>Livros</h1> </div>
    <a class="botao" href="${pageContext.request.contextPath}/livros?acao=novo">+ Cadastrar livro</a>
</section>
<c:if test="${param.ok eq 'salvo'}"><div class="aviso sucesso" role="status">Livro salvo com sucesso.</div></c:if>
<c:if test="${param.ok eq 'excluido'}"><div class="aviso sucesso" role="status">Livro excluído com sucesso.</div></c:if>
<form method="get" action="${pageContext.request.contextPath}/livros" class="busca">
    <label for="busca">Buscar por título ou autor</label>
    <div class="linha"><input id="busca" name="busca" maxlength="255" value="<c:out value='${busca}'/>" >
    <button class="botao" type="submit">Buscar</button><a class="botao secundario" href="${pageContext.request.contextPath}/livros">Ver todos</a></div>
</form>
<p class="contagem"><c:out value="${livros.size()}"/> livro(s) encontrado(s)</p>
<c:choose>
<c:when test="${empty livros}">
    <section class="vazio"><h2><c:choose><c:when test="${empty busca}"></c:when><c:otherwise>Nenhum livro encontrado.</c:otherwise></c:choose></h2>
    <p><c:choose><c:when test="${empty busca}"></c:when><c:otherwise>Tente outro título ou autor, ou consulte todos os livros.</c:otherwise></c:choose></p></section>
</c:when>
<c:otherwise><section class="grade" aria-label="Livros encontrados">
<c:forEach items="${livros}" var="livro">
    <article class="livro">
        <span class="genero"><c:out value="${livro.genero}"/></span>
        <h2><a href="${pageContext.request.contextPath}/livros?acao=detalhes&amp;id=${livro.id}"><c:out value="${livro.titulo}"/></a></h2>
        <p class="autor"><c:out value="${livro.autor}"/></p>
        <p class="ano">Publicação · <c:out value="${livro.ano}"/></p>
        <div class="acoes"><a class="botao secundario" href="${pageContext.request.contextPath}/livros?acao=detalhes&amp;id=${livro.id}">Ver detalhes</a>
        <a class="editar" href="${pageContext.request.contextPath}/livros?acao=editar&amp;id=${livro.id}">Editar</a></div>
    </article>
</c:forEach></section></c:otherwise>
</c:choose>
<%@ include file="rodape.jspf" %>
