import java.time.Year;
import java.util.Scanner;


public class CadastroLivros {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.println("Informe titulo, autor e ano de publicacao.");

        try {
            System.out.print("Titulo: ");
            String titulo = entrada.nextLine();

            System.out.print("Autor: ");
            String autor = entrada.nextLine();

            System.out.print("Ano de publicacao: ");
            String anoInformado = entrada.nextLine();

            titulo = validarTexto(titulo, "O titulo");
            autor = validarTexto(autor, "O autor");
            if (anoInformado.isBlank()) {
                throw new IllegalArgumentException("O ano e obrigatorio.");
            }

            int ano = Integer.parseInt(anoInformado.strip());
            int anoAtual = Year.now().getValue();
            if (ano < 1 || ano > anoAtual) {
                throw new IllegalArgumentException(
                    "Informe um ano entre 1 e " + anoAtual + "."
                );
            }

           
            Livro livro = new Livro(titulo, autor, ano);
            System.out.println("\nDados validados com sucesso!");
            System.out.println("Titulo: " + livro.getTitulo());
            System.out.println("Autor: " + livro.getAutor());
            System.out.println("Ano: " + livro.getAno());
            
        } catch (NumberFormatException erro) {
            System.out.println("\nAno invalido. Digite apenas um numero inteiro, como 2008.");
            System.out.println("O livro nao foi cadastrado. Execute novamente para corrigir.");

        } catch (IllegalArgumentException erro) {
            System.out.println("\nNao foi possivel cadastrar: " + erro.getMessage());
            System.out.println("Execute novamente para corrigir os dados.");

        } finally {
            entrada.close();
        }
    }

    private static String validarTexto(String valor, String campo) {
        String texto = valor.strip();
        if (texto.isEmpty()) {
            throw new IllegalArgumentException(campo + " e obrigatorio.");
        }
        if (texto.length() > 255) {
            throw new IllegalArgumentException(campo + " deve ter no maximo 255 caracteres.");
        }
        return texto;
    }

    
	
    private static class Livro {
        private final String titulo;
        private final String autor;
        private final int ano;

        Livro(String titulo, String autor, int ano) {
            this.titulo = titulo;
            this.autor = autor;
            this.ano = ano;
        }

        public String getTitulo() { return titulo; }
        public String getAutor() { return autor; }
        public int getAno() { return ano; }
    }
}
